from flask import Flask, render_template, request, redirect, url_for, flash, session
import sqlite3
from pathlib import Path
from datetime import date, datetime

app = Flask(__name__)
app.secret_key = "lablink-demo-secret"
DB = Path(__file__).with_name("lablink.db")

SLOTS = ["09:00-10:00", "10:00-11:00", "11:00-12:00",
         "13:00-14:00", "14:00-15:00", "15:00-16:00"]

def db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with db() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS equipment(
            id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
            department TEXT NOT NULL, category TEXT NOT NULL,
            description TEXT, location TEXT, quantity INTEGER DEFAULT 1)""")
        con.execute("""CREATE TABLE IF NOT EXISTS bookings(
            id INTEGER PRIMARY KEY AUTOINCREMENT, student TEXT NOT NULL,
            department TEXT, equipment_id INTEGER NOT NULL, project TEXT NOT NULL,
            purpose TEXT, deadline TEXT, booking_date TEXT NOT NULL,
            slot TEXT NOT NULL, status TEXT DEFAULT 'Pending',
            faculty_comment TEXT DEFAULT '', created_at TEXT DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(equipment_id) REFERENCES equipment(id))""")
        count = con.execute("SELECT COUNT(*) FROM equipment").fetchone()[0]
        if count == 0:
            con.executemany("""INSERT INTO equipment
                (name,department,category,description,location,quantity)
                VALUES(?,?,?,?,?,?)""", [
                ("Arduino Uno Kit","Electronics","Development Kit","Microcontroller kit for embedded systems projects.","Electronics Lab 2",8),
                ("Raspberry Pi 4","Computer Science","Development Kit","Single-board computer for IoT and computing projects.","IoT Lab",5),
                ("3D Printer","Mechanical","Fabrication","FDM printer for rapid prototyping and model fabrication.","Makerspace",2),
                ("Digital Oscilloscope","Electronics","Test Equipment","Two-channel oscilloscope for circuit testing.","Electronics Lab 1",4),
                ("GPU Workstation","Computer Science","Workstation","High-performance workstation for AI and simulation workloads.","AI Lab",3),
                ("Robotics Workstation","Mechatronics","Workstation","Robotics development and testing station.","Robotics Lab",2),
            ])

def current_role():
    return session.get("role", "Student")

def get_equipment():
    with db() as con:
        return con.execute("SELECT * FROM equipment ORDER BY department,name").fetchall()

def get_bookings():
    with db() as con:
        return con.execute("""SELECT b.*, e.name AS equipment_name, e.location
            FROM bookings b JOIN equipment e ON e.id=b.equipment_id
            ORDER BY b.booking_date DESC, b.slot""").fetchall()

def slot_is_free(equipment_id, day, slot):
    with db() as con:
        row = con.execute("""SELECT COUNT(*) FROM bookings
            WHERE equipment_id=? AND booking_date=? AND slot=?
            AND status IN ('Pending','Approved')""", (equipment_id, day, slot)).fetchone()
        return row[0] == 0

def recommend_slots(equipment_id, day, deadline, student):
    # Explainable scheduling: available slots first, then prefer students with
    # fewer existing bookings; if a deadline is close, keep near-term slots high.
    available = [s for s in SLOTS if slot_is_free(equipment_id, day, s)]
    with db() as con:
        usage = con.execute("""SELECT COUNT(*) FROM bookings
            WHERE student=? AND status IN ('Pending','Approved')""", (student,)).fetchone()[0]
    try:
        days_left = (date.fromisoformat(deadline) - date.fromisoformat(day)).days
    except Exception:
        days_left = 30
    # Available slots are equally feasible; include fairness/deadline explanation.
    return available[:3], usage, days_left

@app.route("/", methods=["GET"])
def home():
    role = current_role()
    equipment = get_equipment()
    bookings = get_bookings()
    q = request.args.get("q", "").strip().lower()
    department = request.args.get("department", "")
    if q:
        equipment = [e for e in equipment if q in e["name"].lower() or q in (e["category"] or "").lower()]
    if department:
        equipment = [e for e in equipment if e["department"] == department]
    departments = sorted({e["department"] for e in get_equipment()})
    with db() as con:
        pending_count = con.execute("SELECT COUNT(*) FROM bookings WHERE status='Pending'").fetchone()[0]
        approved_count = con.execute("SELECT COUNT(*) FROM bookings WHERE status='Approved'").fetchone()[0]
    return render_template("index.html", role=role, equipment=equipment,
        bookings=bookings, departments=departments, slots=SLOTS, all_equipment=get_equipment(),
        today=date.today().isoformat(), pending_count=pending_count,
        approved_count=approved_count)

@app.route("/role", methods=["POST"])
def change_role():
    role = request.form.get("role", "Student")
    if role not in ("Student", "Faculty", "Admin"):
        role = "Student"
    session["role"] = role
    return redirect(url_for("home"))

@app.route("/book", methods=["POST"])
def book():
    if current_role() != "Student":
        flash("Switch to the Student role to submit a booking request.", "error")
        return redirect(url_for("home"))
    student = request.form.get("student", "").strip()
    department = request.form.get("department", "").strip()
    equipment_id = request.form.get("equipment_id", type=int)
    project = request.form.get("project", "").strip()
    purpose = request.form.get("purpose", "").strip()
    deadline = request.form.get("deadline", "").strip()
    booking_date = request.form.get("booking_date", "").strip()
    slot = request.form.get("slot", "").strip()
    if not all([student, equipment_id, project, deadline, booking_date, slot]) or slot not in SLOTS:
        flash("Please complete all required booking fields.", "error")
        return redirect(url_for("home"))
    if booking_date < date.today().isoformat() or deadline < booking_date:
        flash("Choose a future booking date and a project deadline on or after the booking date.", "error")
        return redirect(url_for("home"))
    with db() as con:
        exists = con.execute("SELECT id FROM equipment WHERE id=?", (equipment_id,)).fetchone()
        if not exists:
            flash("The selected equipment could not be found.", "error")
            return redirect(url_for("home"))
    if not slot_is_free(equipment_id, booking_date, slot):
        suggestions, usage, days_left = recommend_slots(equipment_id, booking_date, deadline, student)
        if suggestions:
            flash("That slot is already requested or booked. Suggested available slots: " +
                  ", ".join(suggestions) + f". Fairness check: you currently have {usage} active request(s); project deadline is {days_left} day(s) after the requested date.", "warning")
        else:
            flash("No slots are currently available for this equipment on that date. Try another date or resource.", "warning")
        return redirect(url_for("home"))
    with db() as con:
        con.execute("""INSERT INTO bookings
            (student,department,equipment_id,project,purpose,deadline,booking_date,slot)
            VALUES(?,?,?,?,?,?,?,?)""",
            (student, department, equipment_id, project, purpose, deadline, booking_date, slot))
    flash("Booking request submitted. It is awaiting faculty approval.", "success")
    return redirect(url_for("home"))

@app.route("/decision/<int:booking_id>", methods=["POST"])
def decision(booking_id):
    if current_role() not in ("Faculty", "Admin"):
        flash("Only faculty or admin users can process requests.", "error")
        return redirect(url_for("home"))
    action = request.form.get("action")
    comment = request.form.get("comment", "").strip()
    if action not in ("Approved", "Rejected"):
        flash("Invalid decision.", "error")
        return redirect(url_for("home"))
    with db() as con:
        booking = con.execute("SELECT * FROM bookings WHERE id=?", (booking_id,)).fetchone()
        if not booking or booking["status"] != "Pending":
            flash("This request is no longer pending.", "warning")
            return redirect(url_for("home"))
        if action == "Approved":
            conflict = con.execute("""SELECT COUNT(*) FROM bookings
                WHERE equipment_id=? AND booking_date=? AND slot=?
                AND status='Approved' AND id<>?""",
                (booking["equipment_id"], booking["booking_date"], booking["slot"], booking_id)).fetchone()[0]
            if conflict:
                flash("Another request was approved for this slot. Ask the student to choose an alternative.", "warning")
                return redirect(url_for("home"))
        con.execute("UPDATE bookings SET status=?, faculty_comment=? WHERE id=?",
                    (action, comment, booking_id))
    flash(f"Request #{booking_id} {action.lower()}.", "success")
    return redirect(url_for("home"))

@app.route("/equipment/add", methods=["POST"])
def add_equipment():
    if current_role() != "Admin":
        flash("Only administrators can add equipment.", "error")
        return redirect(url_for("home"))
    fields = [request.form.get(k, "").strip() for k in
              ("name", "department", "category", "description", "location")]
    if not all(fields[:3]):
        flash("Name, department, and category are required.", "error")
        return redirect(url_for("home"))
    with db() as con:
        con.execute("""INSERT INTO equipment(name,department,category,description,location,quantity)
            VALUES(?,?,?,?,?,?)""", (*fields, max(1, request.form.get("quantity", type=int) or 1)))
    flash("Equipment added to the catalogue.", "success")
    return redirect(url_for("home"))

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
